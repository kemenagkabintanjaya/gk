<?php
declare(strict_types=1);
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/helpers.php';

function kemenag_seal(): string
{
    return '<svg class="hdr-seal" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">'
        . '<circle cx="28" cy="28" r="27" fill="rgba(255,255,255,.12)" stroke="rgba(255,255,255,.35)" stroke-width="1.5"/>'
        . '<circle cx="28" cy="28" r="21" fill="rgba(255,255,255,.07)" stroke="rgba(255,255,255,.18)" stroke-width="1"/>'
        . '<rect x="26" y="14" width="4" height="20" rx="1" fill="rgba(255,255,255,.85)"/>'
        . '<rect x="20" y="20" width="16" height="4" rx="1" fill="rgba(255,255,255,.85)"/>'
        . '<path d="M16 38h24v2H16z" fill="rgba(255,255,255,.7)"/>'
        . '<path d="M22 38V34h12v4H22z" fill="rgba(255,255,255,.55)"/>'
        . '<path d="M10 22l.6 1.8 1.8.6-1.8.6-.6 1.8-.6-1.8-1.8-.6 1.8-.6L10 22z" fill="rgba(255,215,0,.75)"/>'
        . '<path d="M46 22l.6 1.8 1.8.6-1.8.6-.6 1.8-.6-1.8-1.8-.6 1.8-.6L46 22z" fill="rgba(255,215,0,.75)"/>'
        . '</svg>';
}

function nav_items(): array
{
    $role  = user_role();
    $items = [
        ['dashboard.php',  '📊 Dashboard',   ['administrator', 'kepala_seksi', 'penyuluh']],
        ['data.php',       '📋 Data Gereja', ['administrator', 'kepala_seksi', 'penyuluh']],
        ['verifikasi.php', '✅ Verifikasi',      ['administrator', 'kepala_seksi']],
        ['users.php',      '👤 Pengguna',    ['administrator']],
    ];
    return array_values(array_filter($items, static fn($i) => in_array($role, $i[2], true)));
}

function layout_header(string $title, string $active = ''): void
{
    $u = current_user();
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?> — <?= e(APP_NAME) ?></title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,300&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="kemenag-header">
  <div class="hdr-top">
    <?= kemenag_seal() ?>
    <div class="hdr-text">
      <h1>Pendataan Gereja Kristen — Kemenag Kab. Intan Jaya</h1>
      <p>BIMBINGAN MASYARAKAT KRISTEN · KABUPATEN INTAN JAYA · PROVINSI PAPUA TENGAH</p>
    </div>
    <div class="hdr-user">
      <div class="hu-name"><?= e($u['nama_lengkap'] ?? '') ?></div>
      <div class="hu-role"><?= e(role_label($u['role'] ?? '')) ?><?= !empty($u['distrik']) ? ' · ' . e($u['distrik']) : '' ?></div>
    </div>
  </div>
  <nav class="hdr-nav">
    <?php foreach (nav_items() as $it): ?>
      <a class="nav-btn <?= $active === $it[0] ? 'active' : '' ?>" href="<?= e($it[0]) ?>"><?= $it[1] ?></a>
    <?php endforeach; ?>
    <a class="nav-btn" href="profile.php">🔑 Profil</a>
    <a class="nav-btn nav-logout" href="logout.php">⏻ Keluar</a>
  </nav>
</header>
<div class="wrap">
<?php foreach (get_flashes() as $f): ?>
  <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
<?php endforeach; ?>
<?php
}

function layout_footer(): void
{
    ?>
</div>
<footer class="site-footer">
  <p>Bimbingan Masyarakat Kristen — Kantor Kementerian Agama Kabupaten Intan Jaya · Provinsi Papua Tengah</p>
  <p style="margin-top:4px"><a href="mailto:bimaskristenintanjaya@kemenag.go.id">bimaskristenintanjaya@kemenag.go.id</a></p>
  <p style="margin-top:4px;opacity:.5">Sistem Pendataan v<?= e(APP_VERSION) ?> · Tahun Anggaran 2026</p>
</footer>
</body>
</html>
<?php
}
