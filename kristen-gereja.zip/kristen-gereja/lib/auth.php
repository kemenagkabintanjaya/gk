<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

/** Memulai sesi dengan parameter cookie yang aman. */
function session_boot(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name(SESSION_NAME);
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? '') == 443);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'secure'   => $secure,
        'samesite' => 'Lax',
    ]);
    session_start();

    $now = time();
    if (isset($_SESSION['last_activity']) && ($now - (int)$_SESSION['last_activity'] > SESSION_LIFETIME)) {
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['last_activity'] = $now;
}

/** Token CSRF. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $t = $_POST['csrf'] ?? '';
    if (!is_string($t) || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
        http_response_code(419);
        exit('Token keamanan tidak valid. Silakan muat ulang halaman dan coba lagi.');
    }
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user']);
}

function user_role(): string
{
    return current_user()['role'] ?? '';
}

/** Proses login. Mengembalikan true bila berhasil. */
function login_user(string $username, string $password): bool
{
    $stmt = db()->prepare('SELECT * FROM users WHERE username = ? AND aktif = 1');
    $stmt->execute([$username]);
    $u = $stmt->fetch();

    if (!$u || !password_verify($password, $u['password_hash'])) {
        return false;
    }
    if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
        $up = db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
        $up->execute([password_hash($password, PASSWORD_DEFAULT), $u['id']]);
    }

    session_regenerate_id(true);
    unset($u['password_hash']);
    $u['id'] = (int)$u['id'];
    $_SESSION['user'] = $u;
    db()->prepare("UPDATE users SET last_login = datetime('now','localtime') WHERE id = ?")->execute([$u['id']]);
    log_activity('login', 'Login berhasil');
    return true;
}

function logout_user(): void
{
    log_activity('logout', 'Logout');
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function require_login(): void
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

function require_role(array $roles): void
{
    require_login();
    if (!in_array(current_user()['role'], $roles, true)) {
        http_response_code(403);
        exit('403 — Anda tidak memiliki hak akses untuk halaman ini.');
    }
}

/** Pemeriksaan hak akses granular. */
function can(string $action, ?array $row = null): bool
{
    $u = current_user();
    if (!$u) {
        return false;
    }
    $role = $u['role'];
    switch ($action) {
        case 'manage_users':
            return $role === 'administrator';
        case 'create_gereja':
            return in_array($role, ['administrator', 'kepala_seksi', 'penyuluh'], true);
        case 'delete_gereja':
            return $role === 'administrator';
        case 'verify_gereja':
            return in_array($role, ['administrator', 'kepala_seksi'], true);
        case 'edit_gereja':
            if (in_array($role, ['administrator', 'kepala_seksi'], true)) {
                return true;
            }
            if ($role === 'penyuluh' && $row) {
                $sameDistrik = ($row['distrik'] ?? '') !== '' && ($row['distrik'] ?? '') === ($u['distrik'] ?? "\0");
                $owner = (int)($row['created_by'] ?? 0) === (int)$u['id'];
                return $sameDistrik || $owner;
            }
            return false;
        default:
            return false;
    }
}

function role_label(string $role): string
{
    return [
        'administrator' => 'Administrator',
        'kepala_seksi'  => 'Kepala Seksi Bimas Kristen',
        'penyuluh'      => 'Penyuluh',
    ][$role] ?? $role;
}

function log_activity(string $aksi, string $ket = ''): void
{
    try {
        $uid = current_user()['id'] ?? null;
        $ip  = $_SERVER['REMOTE_ADDR'] ?? '';
        db()->prepare('INSERT INTO activity_log (user_id, aksi, keterangan, ip) VALUES (?,?,?,?)')
            ->execute([$uid, $aksi, $ket, $ip]);
    } catch (Throwable $e) {
        // abaikan kegagalan logging
    }
}
