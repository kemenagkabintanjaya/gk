<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';

/**
 * Mengembalikan koneksi PDO SQLite tunggal (singleton).
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        if (!is_dir(STORAGE_DIR)) {
            @mkdir(STORAGE_DIR, 0775, true);
        }
        $pdo = new PDO('sqlite:' . DB_PATH);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA journal_mode = WAL');
    }
    return $pdo;
}

/**
 * Membuat seluruh tabel bila belum ada.
 */
function db_init(): void
{
    $pdo = db();

    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        username      TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        nama_lengkap  TEXT NOT NULL,
        role          TEXT NOT NULL CHECK(role IN ('administrator','kepala_seksi','penyuluh')),
        distrik       TEXT,
        aktif         INTEGER NOT NULL DEFAULT 1,
        last_login    TEXT,
        created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS distrik (
        id   INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL UNIQUE
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS gereja (
        id                   INTEGER PRIMARY KEY AUTOINCREMENT,
        -- I. Identitas Utama Gereja
        nama_gereja          TEXT NOT NULL,
        singkatan            TEXT,
        alamat               TEXT,
        desa_kelurahan       TEXT,
        distrik              TEXT,
        kode_pos             TEXT,
        telepon              TEXT,
        aras_organisasi      TEXT NOT NULL DEFAULT 'Jemaat',
        nama_sinode          TEXT,
        -- II. Legalitas & Dokumen Administrasi
        no_imb               TEXT,
        tahun_berdiri        INTEGER,
        no_sk_pendirian      TEXT,
        no_sk_pendeta        TEXT,
        no_sk_kemenag        TEXT,
        status_registrasi    TEXT NOT NULL DEFAULT 'Belum Terdaftar',
        no_registrasi_daerah TEXT,
        -- III. Profil Fisik & Fasilitas
        gedung_permanen      INTEGER NOT NULL DEFAULT 0,
        gedung_semi          INTEGER NOT NULL DEFAULT 0,
        gedung_darurat       INTEGER NOT NULL DEFAULT 0,
        milik_sendiri        INTEGER NOT NULL DEFAULT 0,
        milik_sewa           INTEGER NOT NULL DEFAULT 0,
        milik_lain           INTEGER NOT NULL DEFAULT 0,
        kapasitas            INTEGER NOT NULL DEFAULT 0,
        perpustakaan         TEXT NOT NULL DEFAULT 'Tidak Ada',
        -- IV. Kependudukan & Demografi Jemaat
        bapak                INTEGER NOT NULL DEFAULT 0,
        ibu                  INTEGER NOT NULL DEFAULT 0,
        pemuda               INTEGER NOT NULL DEFAULT 0,
        remaja               INTEGER NOT NULL DEFAULT 0,
        anak_sm              INTEGER NOT NULL DEFAULT 0,
        total_warga_gereja   INTEGER NOT NULL DEFAULT 0,
        laki                 INTEGER NOT NULL DEFAULT 0,
        perempuan            INTEGER NOT NULL DEFAULT 0,
        -- V. Pimpinan Jemaat & Pengurus Inti
        pimpinan_nama        TEXT,
        pimpinan_jk          TEXT,
        pimpinan_ttl         TEXT,
        pimpinan_alamat      TEXT,
        pimpinan_hp          TEXT,
        pimpinan_mulai       TEXT,
        pimpinan_pendidikan  TEXT,
        pengurus_ketua       TEXT,
        pengurus_sekretaris  TEXT,
        pengurus_bendahara   TEXT,
        pengurus_koster      TEXT,
        -- VI. Personil Pelayanan (P = pria, W = wanita)
        pdt_p INTEGER NOT NULL DEFAULT 0, pdt_w INTEGER NOT NULL DEFAULT 0,
        pdm_p INTEGER NOT NULL DEFAULT 0, pdm_w INTEGER NOT NULL DEFAULT 0,
        pdp_p INTEGER NOT NULL DEFAULT 0, pdp_w INTEGER NOT NULL DEFAULT 0,
        majelis_p INTEGER NOT NULL DEFAULT 0, majelis_w INTEGER NOT NULL DEFAULT 0,
        diaken_p INTEGER NOT NULL DEFAULT 0, diaken_w INTEGER NOT NULL DEFAULT 0,
        guru_injil_p INTEGER NOT NULL DEFAULT 0, guru_injil_w INTEGER NOT NULL DEFAULT 0,
        guru_sm_p INTEGER NOT NULL DEFAULT 0, guru_sm_w INTEGER NOT NULL DEFAULT 0,
        penginjil_p INTEGER NOT NULL DEFAULT 0, penginjil_w INTEGER NOT NULL DEFAULT 0,
        total_personil INTEGER NOT NULL DEFAULT 0,
        -- VII. Media Komunikasi & Keterangan
        email                TEXT,
        media_sosial         TEXT,
        jadwal_ibadah        TEXT,
        keterangan           TEXT,
        -- Verifikasi & metadata
        status_verifikasi    TEXT NOT NULL DEFAULT 'Belum Diverifikasi',
        catatan_verifikasi   TEXT,
        verified_by          INTEGER,
        verified_at          TEXT,
        created_by           INTEGER,
        created_at           TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        updated_at           TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS activity_log (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id    INTEGER,
        aksi       TEXT,
        keterangan TEXT,
        ip         TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )");
}
