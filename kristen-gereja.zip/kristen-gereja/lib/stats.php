<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';

/**
 * Menghitung seluruh statistik agregat dari tabel gereja (versi Kristen).
 * $scopeDistrik opsional untuk membatasi pada satu distrik.
 */
function compute_statistik(?string $scopeDistrik = null): array
{
    $pdo    = db();
    $where  = '';
    $params = [];
    if ($scopeDistrik !== null && $scopeDistrik !== '') {
        $where    = ' WHERE distrik = ?';
        $params[] = $scopeDistrik;
    }

    $sql = "SELECT
        COUNT(*) AS total,
        COALESCE(SUM(aras_organisasi='Jemaat'),0)        AS arasJemaat,
        COALESCE(SUM(aras_organisasi='Resort/Klasis'),0) AS arasResort,
        COALESCE(SUM(aras_organisasi='Wilayah'),0)       AS arasWilayah,
        COALESCE(SUM(aras_organisasi='Sinode'),0)        AS arasSinode,
        COALESCE(SUM(total_warga_gereja),0) AS totalUmat,
        COALESCE(SUM(laki),0)        AS laki,
        COALESCE(SUM(perempuan),0)   AS perempuan,
        COALESCE(SUM(bapak),0)       AS bapak,
        COALESCE(SUM(ibu),0)         AS ibu,
        COALESCE(SUM(pemuda),0)      AS pemuda,
        COALESCE(SUM(remaja),0)      AS remaja,
        COALESCE(SUM(anak_sm),0)     AS anakSm,
        COALESCE(SUM(gedung_permanen),0) AS gedungPermanen,
        COALESCE(SUM(gedung_semi),0)     AS gedungSemiPermanen,
        COALESCE(SUM(gedung_darurat),0)  AS gedungDarurat,
        COALESCE(SUM(milik_sendiri),0)   AS milikSendiri,
        COALESCE(SUM(milik_sewa),0)      AS milikSewa,
        COALESCE(SUM(milik_lain),0)      AS milikLain,
        COALESCE(SUM(kapasitas),0)       AS kapasitas,
        COALESCE(SUM(perpustakaan='Ada'),0) AS adaPerpustakaan,
        COALESCE(SUM(status_registrasi='Terdaftar'),0) AS terdaftar,
        COALESCE(SUM(pdt_p+pdt_w),0)        AS totPdt,
        COALESCE(SUM(pdm_p+pdm_w),0)        AS totPdm,
        COALESCE(SUM(pdp_p+pdp_w),0)        AS totPdp,
        COALESCE(SUM(majelis_p+majelis_w),0) AS totMajelis,
        COALESCE(SUM(diaken_p+diaken_w),0)  AS totDiaken,
        COALESCE(SUM(guru_injil_p+guru_injil_w),0) AS totGuruInjil,
        COALESCE(SUM(guru_sm_p+guru_sm_w),0) AS totGuruSm,
        COALESCE(SUM(penginjil_p+penginjil_w),0) AS totPenginjil,
        COALESCE(SUM(total_personil),0)  AS totalPersonil,
        COALESCE(SUM(gedung_permanen+gedung_semi+gedung_darurat),0) AS totalGedung,
        COALESCE(SUM(status_verifikasi='Terverifikasi'),0)      AS terverifikasi,
        COALESCE(SUM(status_verifikasi='Belum Diverifikasi'),0) AS belumVerifikasi,
        COALESCE(SUM(status_verifikasi='Ditolak'),0)           AS ditolak,
        MAX(updated_at) AS lastUpdate
      FROM gereja" . $where;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $s = $stmt->fetch() ?: [];

    foreach ($s as $k => $v) {
        if ($k !== 'lastUpdate') {
            $s[$k] = (int)$v;
        }
    }

    // Distribusi berdasarkan Aras Organisasi Gereja
    $s['perAras'] = [
        ['label' => 'Jemaat',        'nilai' => $s['arasJemaat'] ?? 0,  'warna' => '#0D6E4D'],
        ['label' => 'Resort/Klasis', 'nilai' => $s['arasResort'] ?? 0,  'warna' => '#1A9969'],
        ['label' => 'Wilayah',       'nilai' => $s['arasWilayah'] ?? 0, 'warna' => '#B8860B'],
        ['label' => 'Sinode',        'nilai' => $s['arasSinode'] ?? 0,  'warna' => '#1D4ED8'],
    ];

    // Rincian personil pelayanan per jenis
    $s['perPersonil'] = [
        ['label' => 'Pendeta',        'nilai' => $s['totPdt'] ?? 0],
        ['label' => 'Pendeta Muda',   'nilai' => $s['totPdm'] ?? 0],
        ['label' => 'Pendeta Pemb.',  'nilai' => $s['totPdp'] ?? 0],
        ['label' => 'Majelis/Penatua','nilai' => $s['totMajelis'] ?? 0],
        ['label' => 'Diaken/Syamas',  'nilai' => $s['totDiaken'] ?? 0],
        ['label' => 'Guru Injil',     'nilai' => $s['totGuruInjil'] ?? 0],
        ['label' => 'Guru Sek. Minggu','nilai' => $s['totGuruSm'] ?? 0],
        ['label' => 'Penginjil',      'nilai' => $s['totPenginjil'] ?? 0],
    ];

    // Rekap per distrik
    $dq = $pdo->prepare("SELECT
            distrik AS nama,
            COUNT(*) AS jmlGereja,
            COALESCE(SUM(total_warga_gereja),0) AS totalUmat,
            COALESCE(SUM(laki),0) AS laki,
            COALESCE(SUM(perempuan),0) AS perempuan,
            COALESCE(SUM(pemuda),0) AS pemuda
        FROM gereja" . $where . "
        GROUP BY distrik
        ORDER BY totalUmat DESC");
    $dq->execute($params);
    $per = $dq->fetchAll();
    foreach ($per as &$p) {
        $p['jmlGereja'] = (int)$p['jmlGereja'];
        $p['totalUmat'] = (int)$p['totalUmat'];
        $p['laki']      = (int)$p['laki'];
        $p['perempuan'] = (int)$p['perempuan'];
        $p['pemuda']    = (int)$p['pemuda'];
        if ($p['nama'] === null || $p['nama'] === '') {
            $p['nama'] = '(Tanpa Distrik)';
        }
    }
    unset($p);
    $s['perDistrik'] = $per;

    $s['updateTime'] = !empty($s['lastUpdate'])
        ? date('d M Y, H:i', strtotime($s['lastUpdate'])) . ' WIT'
        : 'Belum ada data';

    return $s;
}
