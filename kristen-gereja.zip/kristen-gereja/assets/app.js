'use strict';

const charts = {};
const PALETTE = ['#0D6E4D', '#1A9969', '#B8860B', '#1D4ED8', '#DC2626', '#7C3AED', '#D97706', '#0891B2'];

function fmt(n) {
  n = Number(n || 0);
  return n.toLocaleString('id-ID');
}
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}
function destroyChart(id) {
  if (charts[id]) { charts[id].destroy(); delete charts[id]; }
}

function switchTab(tab) {
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  document.querySelectorAll('.subtab-btn').forEach(b => b.classList.remove('active'));
  const content = document.getElementById('tab-' + tab);
  if (content) content.classList.add('active');
  const btn = document.querySelector('.subtab-btn[data-tab="' + tab + '"]');
  if (btn) btn.classList.add('active');
}

function donut(canvasId, legendId, items) {
  destroyChart(canvasId);
  const el = document.getElementById(canvasId);
  if (!el) return;
  const labels = items.map(i => i.label);
  const data = items.map(i => i.nilai);
  const colors = items.map((i, idx) => i.warna || PALETTE[idx % PALETTE.length]);
  charts[canvasId] = new Chart(el, {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 2, borderColor: '#fff' }] },
    options: { responsive: true, maintainAspectRatio: false, cutout: '62%', plugins: { legend: { display: false } } }
  });
  const total = data.reduce((a, b) => a + b, 0) || 1;
  const legend = document.getElementById(legendId);
  if (legend) {
    legend.innerHTML = items.map((i, idx) => {
      const pct = Math.round((Number(i.nilai) / total) * 100);
      const c = i.warna || PALETTE[idx % PALETTE.length];
      return '<div class="leg-item"><span class="leg-dot" style="background:' + c + '"></span>' +
        i.label + ' <span class="leg-pct">' + fmt(i.nilai) + ' · ' + pct + '%</span></div>';
    }).join('');
  }
}

function barCanvas(canvasId, labels, data, color) {
  destroyChart(canvasId);
  const el = document.getElementById(canvasId);
  if (!el) return;
  charts[canvasId] = new Chart(el, {
    type: 'bar',
    data: { labels, datasets: [{ data, backgroundColor: color || '#0D6E4D', borderRadius: 6, maxBarThickness: 46 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
    }
  });
}

function renderBars(containerId, items) {
  const wrap = document.getElementById(containerId);
  if (!wrap) return;
  const max = Math.max(1, ...items.map(i => Number(i.nilai)));
  wrap.innerHTML = items.map(i => {
    const w = Math.round((Number(i.nilai) / max) * 100);
    return '<div class="bar-row"><span class="bar-lbl">' + i.label + '</span>' +
      '<span class="bar-track"><span class="bar-fill" style="width:' + w + '%"></span></span>' +
      '<span class="bar-val">' + fmt(i.nilai) + '</span></div>';
  }).join('');
}

function renderAll(s) {
  // Info banner
  setText('ib-total', fmt(s.total));
  setText('ib-umat', fmt(s.totalUmat));
  setText('ib-ver', fmt(s.terverifikasi));
  setText('ib-update', s.updateTime || '–');

  // Ringkasan cards
  setText('s-total', fmt(s.total));
  setText('s-umat', fmt(s.totalUmat));
  setText('s-gedung', fmt(s.totalGedung));
  setText('s-permanen', fmt(s.gedungPermanen));
  setText('s-personil', fmt(s.totalPersonil));
  setText('s-pendeta', fmt(s.totPdt));
  setText('s-terdaftar', fmt(s.terdaftar));
  setText('s-ver', fmt(s.terverifikasi));

  // Donut aras
  donut('chart-aras', 'legend-aras', s.perAras || []);

  // Donut kondisi gedung
  donut('chart-gedung', 'legend-gedung', [
    { label: 'Permanen', nilai: s.gedungPermanen, warna: '#0D6E4D' },
    { label: 'Semi Permanen', nilai: s.gedungSemiPermanen, warna: '#B8860B' },
    { label: 'Darurat', nilai: s.gedungDarurat, warna: '#DC2626' }
  ]);

  // Bar jemaat per distrik
  const ld = document.getElementById('loader-distrik');
  if (ld) ld.style.display = 'none';
  const perDist = (s.perDistrik || []).slice(0, 12);
  renderBars('bar-distrik', perDist.map(d => ({ label: d.nama, nilai: d.totalUmat })));

  // Bar personil pelayanan
  const pp = s.perPersonil || [];
  barCanvas('chart-personil', pp.map(p => p.label), pp.map(p => p.nilai), '#1D4ED8');

  // Demografi cards
  setText('dem-laki', fmt(s.laki));
  setText('dem-perempuan', fmt(s.perempuan));
  setText('dem-bapak', fmt(s.bapak));
  setText('dem-ibu', fmt(s.ibu));
  setText('dem-pemuda', fmt(s.pemuda));
  setText('dem-remaja', fmt(s.remaja));
  setText('dem-anaksm', fmt(s.anakSm));
  setText('dem-pendeta', fmt(s.totPdt));

  // Donut gender
  donut('chart-gender', 'legend-gender', [
    { label: 'Laki-laki', nilai: s.laki, warna: '#1D4ED8' },
    { label: 'Perempuan', nilai: s.perempuan, warna: '#DB2777' }
  ]);

  // Bar unsur jemaat
  barCanvas('chart-unsur',
    ['Bapak', 'Ibu', 'Pemuda', 'Remaja', 'Anak SM'],
    [s.bapak, s.ibu, s.pemuda, s.remaja, s.anakSm], '#0D6E4D');

  // Tabel per distrik
  const tbody = document.getElementById('tbl-distrik-body');
  setText('distrik-count', (s.perDistrik || []).length + ' distrik');
  if (tbody) {
    if (!perDist.length) {
      tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state">Belum ada data.</div></td></tr>';
    } else {
      tbody.innerHTML = (s.perDistrik || []).map((d, idx) =>
        '<tr><td>' + (idx + 1) + '</td><td><strong>' + d.nama + '</strong></td><td>' + fmt(d.jmlGereja) +
        '</td><td>' + fmt(d.totalUmat) + '</td><td>' + fmt(d.laki) + '</td><td>' + fmt(d.perempuan) +
        '</td><td>' + fmt(d.pemuda) + '</td></tr>'
      ).join('');
    }
  }
}

async function loadData() {
  try {
    const res = await fetch('api.php?action=statistik', { headers: { 'X-Requested-With': 'fetch' } });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const s = await res.json();
    renderAll(s);
  } catch (err) {
    console.error('Gagal memuat statistik:', err);
    const ld = document.getElementById('loader-distrik');
    if (ld) ld.innerHTML = '<span style="color:#DC2626;font-size:13px">Gagal memuat data.</span>';
  }
}

document.addEventListener('DOMContentLoaded', loadData);
